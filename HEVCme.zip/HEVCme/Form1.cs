﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediaInfoLib;

namespace HEVCme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string workDir = "";
        private void convertIt(string ffmpegsetup)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow = false;
            startInfo.UseShellExecute = false;
            startInfo.FileName = "ffmpeg.exe";
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;
            startInfo.Arguments = ffmpegsetup;
            using (Process exeProcess = Process.Start(startInfo))
            {
                exeProcess.WaitForExit();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if ((findAvi.CheckState == CheckState.Unchecked) && (findMkv.CheckState == CheckState.Unchecked) && (findMp4.CheckState == CheckState.Unchecked))
            {
                MessageBox.Show("You haven't selected any file types");
            }
            else
            {
                FolderBrowserDialog fbd = new FolderBrowserDialog();
                fbd.ShowNewFolderButton = false;
                DialogResult dialogResult = fbd.ShowDialog();
                if (dialogResult == DialogResult.OK)
                {
                    workDir += fbd.SelectedPath.ToString();
                    if (findAvi.CheckState == CheckState.Checked)
                    {
                        string[] aviFiles = Directory.GetFiles(fbd.SelectedPath, "*.avi", SearchOption.TopDirectoryOnly);
                        checkedFilesList.Items.AddRange(aviFiles);
                    }
                    if (findMp4.CheckState == CheckState.Checked)
                    {
                        string[] mp4Files = Directory.GetFiles(fbd.SelectedPath, "*.mp4", SearchOption.TopDirectoryOnly);
                        checkedFilesList.Items.AddRange(mp4Files);
                    }
                    if (findMkv.CheckState == CheckState.Checked)
                    {
                        string[] mkvFiles = Directory.GetFiles(fbd.SelectedPath, "*.mkv", SearchOption.TopDirectoryOnly);
                        checkedFilesList.Items.AddRange(mkvFiles);
                    }
                }
            }
        }

        private void useNvidia_CheckedChanged(object sender, EventArgs e)
        {
            if (useNvidia.CheckState == CheckState.Checked)
            {
                chkQp.Enabled = true;
                encodeCPU.CheckState = CheckState.Unchecked;
                chkCRF.CheckState = CheckState.Unchecked;
                chkCRF.Enabled = false;
            }
            if(useNvidia.CheckState == CheckState.Unchecked)
            {
                chkCRF.Enabled = true;
                encodeCPU.CheckState = CheckState.Checked;
                chkQp.CheckState = CheckState.Unchecked;
                chkQp.Enabled = false;

            }
        }

        private void encodeCPU_CheckedChanged(object sender, EventArgs e)
        {
            if (encodeCPU.CheckState == CheckState.Checked)
            {
                useNvidia.CheckState = CheckState.Unchecked;
                chkQp.CheckState = CheckState.Unchecked;
            }
            if (encodeCPU.CheckState == CheckState.Unchecked)
            {
                useNvidia.CheckState = CheckState.Checked;
                chkCRF.CheckState = CheckState.Unchecked;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chkCustomBr_CheckedChanged(object sender, EventArgs e)
        {
            if(chkCustomBr.CheckState == CheckState.Checked)
            {
                chkCRF.CheckState = CheckState.Unchecked;
                chkQp.CheckState = CheckState.Unchecked;
            }
        }

        private void chkQp_CheckedChanged(object sender, EventArgs e)
        {
            if(chkQp.CheckState == CheckState.Checked)
            {
                chkCRF.CheckState = CheckState.Unchecked;
                chkCustomBr.CheckState = CheckState.Unchecked;
            }
        }

        private void chkCRF_CheckedChanged(object sender, EventArgs e)
        {
            if(chkCRF.CheckState == CheckState.Checked)
            {
                chkQp.CheckState = CheckState.Unchecked;
                chkCustomBr.CheckState = CheckState.Unchecked;
            }
        }

        private void chkCopyAud_CheckedChanged(object sender, EventArgs e)
        {
            if(chkCopyAud.CheckState == CheckState.Checked)
            {
                chkAudCustomBr.CheckState = CheckState.Unchecked;
                chkEncodeAud.CheckState = CheckState.Unchecked;
                chkEncodeAud.Enabled = false;
                chkAudCustomBr.Enabled = false;
            }
            if (chkCopyAud.CheckState == CheckState.Unchecked)
            {
                chkAudCustomBr.CheckState = CheckState.Unchecked;
                chkEncodeAud.CheckState = CheckState.Unchecked;
                chkEncodeAud.Enabled = true;
                chkAudCustomBr.Enabled = true;
            }
        }

        private void chkEncodeAud_CheckedChanged(object sender, EventArgs e)
        {
            if(chkEncodeAud.CheckState == CheckState.Checked)
            {
                chkCopyAud.CheckState = CheckState.Unchecked;
                chkCopyAud.Enabled = false;
            }
            if (chkEncodeAud.CheckState == CheckState.Unchecked)
            {
                chkCopyAud.CheckState = CheckState.Unchecked;
                chkCopyAud.Enabled = true;
            }
        }

        private void chkAudCustomBr_CheckedChanged(object sender, EventArgs e)
        {
            if(chkAudCustomBr.CheckState == CheckState.Checked)
            {
                chkCopyAud.CheckState = CheckState.Unchecked;
                chkCopyAud.Enabled = false;
                chkEncodeAud.CheckState = CheckState.Checked;
            }
            if (chkAudCustomBr.CheckState == CheckState.Unchecked)
            {
                chkCopyAud.CheckState = CheckState.Unchecked;
                chkCopyAud.Enabled = true;
                chkEncodeAud.CheckState = CheckState.Checked;
                chkEncodeAud.CheckState = CheckState.Unchecked;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ffargs = "";
            if ((useNvidia.CheckState == CheckState.Unchecked) && (encodeCPU.CheckState == CheckState.Unchecked))
            {
                MessageBox.Show("You haven't selected either Nvidia or CPU!");
                return;
            }
            if ((chkCRF.CheckState == CheckState.Unchecked) && (chkQp.CheckState == CheckState.Unchecked) && (chkCustomBr.CheckState == CheckState.Unchecked))
            {
                MessageBox.Show("You havent selected an encoding methos (CONSTQP, CRF, Custom Bitrate)");
                return;
            }
            if((chkCustomBr.CheckState == CheckState.Checked) && ((textAvVidBr.Text == "") || (textMaxVidBr.Text == "")))
            {
                MessageBox.Show("You have selected a custom bitrate but your bitrate box is empty!");
                return;
            }
            if ((useNvidia.CheckState == CheckState.Checked) && (chkQp.CheckState == CheckState.Checked))
            {
                ffargs += "-c:v hevc_nvenc -rc constqp -cq " + cqVal.Text + " -rc-lookahead 32 -g 600 ";
            }
            if ((encodeCPU.CheckState == CheckState.Checked) && (chkCRF.CheckState == CheckState.Checked))
            {
                ffargs += "-c:v libx265 -crf " + crfVal.Text + " -x265-params rc-lookahead=32:intra-refresh=1:ctu=32:ref=1:bframes=0:keyint=150:min-keyint=150:aq-mode=2:aq-strength=1.0:no-aq-motion=1:qg-size=16:no-cutree=1 ";
            }
            if ((useNvidia.CheckState == CheckState.Checked) && (chkCustomBr.CheckState == CheckState.Checked))
            {
                ffargs += "-c:v hevc_nvenc -rc vbr_hq -b:v " + textAvVidBr.Text + "k -maxrate:v " + textMaxVidBr.Text + "k -rc-lookahead 32 -g 600 ";
            }
            if ((encodeCPU.CheckState == CheckState.Checked) && (chkCustomBr.CheckState == CheckState.Checked))
            {
                ffargs += "-c:v libx265 -b:v " + textAvVidBr.Text + "k -maxrate:v " + textMaxVidBr.Text + "k -x265-params rc-lookahead=32:intra-refresh=1:ctu=32:ref=1:bframes=0:keyint=150:min-keyint=150:aq-mode=2:aq-strength=1.0:no-aq-motion=1:qg-size=16:no-cutree=1 ";
            }
            if (chkCopyAud.CheckState == CheckState.Checked)
            {
                ffargs += "-c:a copy ";
            }
            if ((chkAudCustomBr.CheckState == CheckState.Checked) && (textAudioBitrate.Text == "") && (chkEncodeAud.CheckState == CheckState.Checked))
            {
                MessageBox.Show("You haven't enterted an audio bitrate");
                return;
            }
            if ((chkAudCustomBr.CheckState == CheckState.Checked) && (chkEncodeAud.CheckState == CheckState.Checked))
            {
            ffargs += "-c:a aac -b:a " + textAudioBitrate.Text + "k ";
            }
            if ((chkAudCustomBr.CheckState == CheckState.Unchecked) && (chkEncodeAud.CheckState == CheckState.Checked))
            {
                ffargs += "-c:a aac ";
            }
            if (chkCopySubs.CheckState == CheckState.Checked)
            {
                ffargs += "-c:s copy ";
            }
            ArrayList selectedFiles = new ArrayList();

            for(int i=0; i < checkedFilesList.Items.Count; i++)
                if (checkedFilesList.GetItemChecked(i))
                {
                    selectedFiles.Add(checkedFilesList.Items[i].ToString());
                }
            if (selectedFiles.Count < 1)
            {
                MessageBox.Show("You haven't selected any files!!!");
                return;
            } else
            {
                for (int j=0; j < selectedFiles.Count; j++)
                {
                    string renameThis = selectedFiles[j].ToString().Split('\\').Last();
                    MessageBox.Show(renameThis + " - " + workDir);
                    MessageBox.Show("-n -i \"" + selectedFiles[j] + "\" " + ffargs + "\"" + selectedFiles[j] + "_converted.mkv\"");
                }
            }
        }

        private void butSelectAll_Click(object sender, EventArgs e)
        {
            for(int a=0; a < checkedFilesList.Items.Count; a++)
            {
                checkedFilesList.SetItemChecked(a, true);
            }
        }

        private void butSelectNone_Click(object sender, EventArgs e)
        {
            for (int a = 0; a < checkedFilesList.Items.Count; a++)
            {
                checkedFilesList.SetItemChecked(a, false);
            }
        }

        private void butMedInf_Click(object sender, EventArgs e)
        {
            String ToDisplay;
            MediaInfo MI = new MediaInfo();

            ToDisplay = MI.Option("Info_Version", "0.7.0.0;MediaInfoDLL_Example_CS;0.7.0.0");
            if (ToDisplay.Length == 0)
            {
                richTextBox1.Text = "MediaInfo.Dll: this version of the DLL is not compatible";
                return;
            }

            //Information about MediaInfo
            ToDisplay += "\r\n\r\nInfo_Parameters\r\n";
            ToDisplay += MI.Option("Info_Parameters");

            ToDisplay += "\r\n\r\nInfo_Capacities\r\n";
            ToDisplay += MI.Option("Info_Capacities");

            ToDisplay += "\r\n\r\nInfo_Codecs\r\n";
            ToDisplay += MI.Option("Info_Codecs");

            //An example of how to use the library
            ToDisplay += "\r\n\r\nOpen\r\n";
            MI.Open("test.mkv");

            ToDisplay += "\r\n\r\nInform with Complete=false\r\n";
            MI.Option("Complete");
            ToDisplay += MI.Inform();

            ToDisplay += "\r\n\r\nInform with Complete=true\r\n";
            MI.Option("Complete", "1");
            ToDisplay += MI.Inform();

            ToDisplay += "\r\n\r\nCustom Inform\r\n";
            MI.Option("Inform", "General;File size is %FileSize% bytes");
            ToDisplay += MI.Inform();

            ToDisplay += "\r\n\r\nGet with Stream=General and Parameter='FileSize'\r\n";
            ToDisplay += MI.Get(0, 0, "FileSize");

            ToDisplay += "\r\n\r\nGet with Stream=General and Parameter=46\r\n";
            ToDisplay += MI.Get(0, 0, 46);

            ToDisplay += "\r\n\r\nCount_Get with StreamKind=Stream_Audio\r\n";
            ToDisplay += MI.Count_Get(StreamKind.Audio);

            ToDisplay += "\r\n\r\nGet with Stream=General and Parameter='AudioCount'\r\n";
            ToDisplay += MI.Get(StreamKind.General, 0, "AudioCount");

            ToDisplay += "\r\n\r\nGet with Stream=Audio and Parameter='StreamCount'\r\n";
            ToDisplay += MI.Get(StreamKind.Audio, 0, "StreamCount");

            ToDisplay += "\r\n\r\nClose\r\n";
            MI.Close();

            //Example with a stream
            //ToDisplay+="\r\n"+ExampleWithStream()+"\r\n";

            //Displaying the text
            richTextBox1.Text = ToDisplay;
        }
    }
}
